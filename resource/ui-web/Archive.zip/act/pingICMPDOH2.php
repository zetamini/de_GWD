<?php
passthru('/opt/de_GWD/ui-pingICMPDOH 2');
die();
?>
