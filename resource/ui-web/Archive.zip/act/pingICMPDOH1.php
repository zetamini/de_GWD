<?php
passthru('/opt/de_GWD/ui-pingICMPDOH 1');
die();
?>
